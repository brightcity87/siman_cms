<?php

	$sm['adminnavigation']['globalclass']='nav nav-pills nav-stacked';

	$sm['adminform']['nohighlight']=true;
	$sm['adminform']['globalclass']='';
	$sm['adminform']['rowclass']='';
	$sm['adminform']['textclass']='';
	$sm['adminform']['selectclass']='';
	$sm['adminform']['textareaclass']='';

	$sm['admintable']['globalclass']='';
	$sm['admintable']['header_tag']='';
	$sm['admintable']['header_th_wrapper_begin']='';
	$sm['admintable']['header_th_wrapper_end']='';

	$sm['contenteditor']['controlbuttonsclass']='btn-xs';

	$sm['adminbuttons']['htmlbegin']='';
	$sm['adminbuttons']['htmlend']='';
	$sm['adminbuttons']['globalclass']='';
	$sm['adminbuttons']['buttonseparator']='';
	$sm['adminbuttons']['buttonclass']='';
	$sm['adminbuttons']['buttonbegin']='';
	$sm['adminbuttons']['buttonend']='';
