function set_visibility(ids)
{
	var element=document.getElementById(ids);
	element.style.display=(element.style.display)?'':'none';
}