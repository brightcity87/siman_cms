<?php

	//------------------------------------------------------------------------------
	//|                                                                            |
	//|            Content Management System SiMan CMS                             |
	//|                                                                            |
	//------------------------------------------------------------------------------

	$modules[$modules_index]["module"] = 'refresh';
	$modules[$modules_index]["title"] = $lang['common']['redirect'];

?>