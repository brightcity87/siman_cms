<?php

	sm_default_action('test');

	if (sm_action('modal'))
		{
			sm_use('ui.interface');
			sm_use('ui.buttons');
			sm_use('ui.exchange');
			sm_title('Modal');
			$ui = new TInterface();
			$b=new TButtons();
			$b->Button('Close');
			$sender=new TExchangeSender($_getvars['listener']);
			$sender->Add('field1', 'Test 1');
			$sender->Add('field2', 'Test 2');
			$sender->SetCloseWindowRequest();
			$b->OnClick($sender->GetJSCode());
			$ui->Add($b);
			$ui->Output(true);
		}
	if (sm_action('post'))
		{
			sm_use('ui.interface');
			sm_title('OK');
			$ui = new TInterface();
			$ui->Output(true);
		}
	if (sm_action('test'))
		{
			sm_use('ui.interface');
			sm_use('ui.form');
			sm_use('ui.exchange');
			sm_title('Test');
			$ui = new TInterface();
			$f = new TForm('index.php?m='.sm_current_module().'&d=post');
			$f->AddText('field1', 'Field 1');
			$f->AddText('field2', 'Field 2');
			$f->AddText('field3', 'Field 3');
			$ui->Add($f);
			$ui->a('index.php?m=testmodule&d=modal&listener='.sm_pageid(), 'Modal', '', '', '', '', 'target="_blank"');
			$listener=new TExchangeListener();
			$listener->Add('field1');
			$listener->Add('field2');
			$listener->Add('field3');
			$ui->javascript($listener->GetJSCode());
			unset($listener);
			$sender=new TExchangeSender(sm_pageid());
			$sender->Add('field3', rand());
			$ui->javascript($sender->GetJSCode());
			unset($sender);
			$ui->Output(true);
		}

?>