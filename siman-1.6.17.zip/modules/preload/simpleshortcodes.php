<?php

	if (!defined("SIMAN_DEFINED"))
		exit('Hacking attempt!');

?>