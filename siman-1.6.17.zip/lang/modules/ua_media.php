<?php

	$lang['module_galleies']['media_files']='Медіа';
	$lang['module_galleies']['galleries']='Галереї';
	$lang['module_galleies']['gallery']='Галерея';
	$lang['module_galleies']['gallery_thumb']='Мініатюра галереї';
	$lang['module_galleies']['gallery_thumb_width']='Ширина мініатюри галереї';
	$lang['module_galleies']['gallery_thumb_height']='Висота мініатюри галереї';
	$lang['module_galleies']['gallery_default_view']='Вигляд галерeї по замовчуванню';
	$lang['module_galleies']['gallery_view_items_per_row']='Кількість елементів в рядку при перегляді галереї';
	$lang['module_galleies']['galleries_view_items_per_row']='Кількість елементів в рядку при перегляді галерей';
	$lang['module_galleies']['galleries_sort']='Сортування галерей';
	$lang['module_galleies']['media_thumb_width']='Ширина мініатюри зображення';
	$lang['module_galleies']['media_thumb_height']='Висота мініатюри зображення';
	$lang['module_galleies']['media_medium_width']='Ширина зображення';
	$lang['module_galleies']['media_meduim_height']='Висота зображення';
	$lang['module_galleies']['media_allowed_extensions']='Дозволені розширення медіа-файлів';
	$lang['module_galleies']['media_edit_after_upload']='Редагувати після завантаження';
	$lang['module_galleies']['all_images_in_one_page']='Всі зображення на одній сторінці';
	$lang['module_galleies']['media_erase_original_image']='Видалити оригінальне зображення після завантаження';
	$lang['module_galleies']['add_at_least_one_image']='Додайте хоча б одне зображення';

