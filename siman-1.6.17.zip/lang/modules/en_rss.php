<?php

	$lang['module_rss']['module_rss'] = 'RSS-Feeds';
	$lang['module_rss']['rss_feeds'] = 'RSS-Feeds';
	$lang['module_rss']['settings']['rss_itemscount'] = 'RSS-feed items count';
	$lang['module_rss']['settings']['rss_showfulltext'] = 'Show full text in RSS-feed';
	$lang['module_rss']['settings']['rss_shownewsctgs'] = 'Add news categories feeds list in head section';
	$lang['module_rss']['settings']['rss_shownimagetag'] = 'Add "image" element wth logo files/img/rss_logo.png to RSS-feed';
	$lang['module_rss']['rss_feed_logo'] = 'RSS feed logo';

?>