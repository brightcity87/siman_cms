<?php

	$lang['module_admin']['shortcuts'] = 'Швидкий доступ';
	$lang['module_admin']['images_media_notification'] = 'Це адміністративний інструмент. Використовуйте модуль <a href="index.php?m=media&d=admin">Media</a> для керування зображеннями веб-сайту.';
	$lang['module_admin']['module'] = 'Модуль';
