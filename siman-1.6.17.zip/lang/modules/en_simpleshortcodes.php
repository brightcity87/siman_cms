<?php

$lang['module_simpleshortcodes']['module_simpleshortcodes']='Simple shorcodes';
$lang['module_simpleshortcodes']['time']='Time';
$lang['module_simpleshortcodes']['date']='Date';
$lang['module_simpleshortcodes']['userinfo']='User details';
$lang['module_simpleshortcodes']['login']='Login';
$lang['module_simpleshortcodes']['email']='E-mail';

?>