<?php

	$lang['module_youtubereplacer']['module_youtubereplacer'] = 'YouTube Replacer';
	$lang['module_youtubereplacer']['replacer'] = 'Time';
	$lang['module_youtubereplacer']['append_youtube_url'] = 'Append YouTube URL';
	$lang['module_youtubereplacer']['start_with_html'] = 'Start With HTML';
	$lang['module_youtubereplacer']['end_with_html'] = 'End With HTML';
