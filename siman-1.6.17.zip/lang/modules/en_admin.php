<?php

	$lang['module_admin']['shortcuts'] = 'Shortcuts';
	$lang['module_admin']['images_media_notification'] = 'This is an administrative tool. Please use <a href="index.php?m=media&d=admin">Media</a> module to manage images of your website.';
	$lang['module_admin']['module'] = 'Module';
