<?php

	$lang['module_galleies']['media_files']='Media';
	$lang['module_galleies']['galleries']='Galleries';
	$lang['module_galleies']['gallery']='Gallery';
	$lang['module_galleies']['gallery_thumb']='Gallery thumb';
	$lang['module_galleies']['gallery_thumb_width']='Gallery thumbnail width';
	$lang['module_galleies']['gallery_thumb_height']='Gallery thumbnail height';
	$lang['module_galleies']['gallery_default_view']='Gallery default view';
	$lang['module_galleies']['gallery_view_items_per_row']='Gallery view items per row';
	$lang['module_galleies']['galleries_view_items_per_row']='Galleries view items per row';
	$lang['module_galleies']['galleries_sort']='Galleries sorting order';
	$lang['module_galleies']['media_thumb_width']='Image thumbnail width';
	$lang['module_galleies']['media_thumb_height']='Image thumbnail height';
	$lang['module_galleies']['media_medium_width']='Image width';
	$lang['module_galleies']['media_meduim_height']='Image height';
	$lang['module_galleies']['media_allowed_extensions']='Allowed media files extensions';
	$lang['module_galleies']['media_edit_after_upload']='Edit after upload';
	$lang['module_galleies']['all_images_in_one_page']='All images at single page';
	$lang['module_galleies']['media_erase_original_image']='Erase original image after upload';
	$lang['module_galleies']['add_at_least_one_image']='Please add at least one image';
