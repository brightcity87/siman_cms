<?php

$lang['module_adminsettings']['module_adminsettings']='Settings (for experts only)';
$lang['module_adminsettings']['really_want_delete']='Are you sure';


?>