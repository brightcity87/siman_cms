jsModal
=======

Modal generator in pure JavaScript
